/* 
Mapping exercise :
Map controls from three different inputs onto the three different filters, each of which are implemented by the following three functions:
image.noise();
image.blurRadius();
image.pixelSize();
Each need a number input as an argument (inside the parentheses) : you'll need to experiment with what range of numbers work for you
You'll need to choose range and step on range input, and remap the preset range on the x & y controls
*/

/* let colourPalette1Input = document.getElementById("palette01");

colourPalette1Input.addEventListener("click", e => {

}); */

/* these two functions run whenever the x and y postition of the controller changes */
function newXValue(value){
    // value has a range of 0 - 100
    // can be remapped via the helper function
    //console.log(`xPos: ${value}`);
}

function newYValue(value){
    // value has a range of 0 - 100
    // can be remapped via the helper function
    //console.log(`yPos: ${value}`);
}


